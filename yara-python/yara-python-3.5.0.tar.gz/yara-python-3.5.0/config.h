/*
  This a dummy file to satisfy some #include "config.h" directives while
  building libyara.
*/
