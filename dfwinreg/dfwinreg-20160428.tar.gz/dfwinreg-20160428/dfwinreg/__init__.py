# -*- coding: utf-8 -*-
"""Digital Forensics Windows Registry (dfWinReg).

dfWinReg, or Digital Forensics Windows Registry, is a Python module
that provides read-only access to Windows Registry objects.
"""

__version__ = '20160428'
