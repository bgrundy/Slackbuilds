Please leave the symlinks in this directory. They are currently needed
to build the windows executable with mingw.
