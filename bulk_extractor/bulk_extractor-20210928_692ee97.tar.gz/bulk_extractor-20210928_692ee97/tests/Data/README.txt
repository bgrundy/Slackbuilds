This is the Data/ directory for bulk_extractor regression testing. 

The contents of this directory are not part of the bulk_extractor
source code release, but they are part of the GitHub source code
distribution. Download bulk_extractor from GitHub to get the full
contents of the directory. You can perform the download with this
command:


git clone --recursive git@github.com:simsong/bulk_extractor.git


