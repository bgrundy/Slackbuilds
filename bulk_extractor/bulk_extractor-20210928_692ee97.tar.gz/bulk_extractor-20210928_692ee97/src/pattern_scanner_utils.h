#include <cinttypes>
#include <string>

using namespace std;

string low_utf16le_to_ascii(const uint8_t* buf, size_t len);

