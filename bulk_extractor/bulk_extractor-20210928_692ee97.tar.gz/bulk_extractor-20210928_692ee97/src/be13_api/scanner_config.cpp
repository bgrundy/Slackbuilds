#include "config.h"

#include <iostream>
#include <sstream>

#include "scanner_config.h"

/************************************
 *** HELP and  option processing  ***
 ************************************/

//void scanner_config::set_config(const std::string& name, const std::string& val) { namevals[name] = val; }
//void scanner_config::push_scanner_command(const std::string& scannerName, scanner_command::command_t c) {
//    scanner_commands.push_back(scanner_command(scannerName, c));
//}
