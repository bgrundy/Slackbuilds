# Sample DFXML
This directory contains sample DFXML files.  The Makefile here runs tests for conformance against the DFXML Schema with `make check`.

Not all of these files are currently conformant; these can be seen with `make --keep-going check-TODO`.
