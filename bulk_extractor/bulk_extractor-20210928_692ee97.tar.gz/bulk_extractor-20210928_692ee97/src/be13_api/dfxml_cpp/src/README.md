This directory contains a C++ implementation for a DFXML reader and
writer. It also contains hash_t, which is a nice class for hashing.
