June 2020:

* Changed license to LGPLv3

* Updated for CommonCrypto on MacOS

* Added support for googletest (gtest) C++ unit test framework
