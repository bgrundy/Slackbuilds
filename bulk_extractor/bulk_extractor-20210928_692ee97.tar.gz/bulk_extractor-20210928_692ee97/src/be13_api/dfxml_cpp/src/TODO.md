* Change timeval to use C++ std::chrono::high_resolution_lclock
* See: http://www.cplusplus.com/reference/chrono/high_resolution_clock/now/
