#ifndef SCAN_SHA1_H
#define SCAN_SHA1_H

#include "scanner_params.h"

scanner_t scan_sha1_test;
#endif
