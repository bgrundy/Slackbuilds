#include "abstract_image_reader.h"

abstract_image_reader::~abstract_image_reader()
{
}
