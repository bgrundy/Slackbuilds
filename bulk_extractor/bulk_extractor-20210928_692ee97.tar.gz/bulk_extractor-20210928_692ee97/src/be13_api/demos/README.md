This directory is little test and demo programs used by the author to learn the ins and outs of C++17
