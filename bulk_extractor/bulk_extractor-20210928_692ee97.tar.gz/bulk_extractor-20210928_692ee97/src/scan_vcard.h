#ifndef SCAN_VCARD_H
#define SCAN_VCARD_H
void carve_vcards(const sbuf_t &sbuf, feature_recorder &vcard_recorder);
#endif
