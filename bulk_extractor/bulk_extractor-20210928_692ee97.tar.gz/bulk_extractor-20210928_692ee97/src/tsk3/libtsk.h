#ifndef _TSK_LIBTSK_H
#define _TSK_LIBTSK_H

#include "tsk3/base/tsk_base.h"
#include "tsk3/img/tsk_img.h"
#include "tsk3/vs/tsk_vs.h"
#include "tsk3/fs/tsk_fs.h"
#include "tsk3/hashdb/tsk_hashdb.h"
#include "tsk3/auto/tsk_auto.h"

#endif
