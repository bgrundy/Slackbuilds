This directory contains old scanners that are either no longer used or that were experimental.
