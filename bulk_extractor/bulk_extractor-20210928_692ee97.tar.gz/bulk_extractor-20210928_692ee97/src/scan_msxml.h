#ifndef SCAN_MSXML_H
#define SCAN_MSXML_H
#include "be13_api/sbuf.h"

std::string msxml_extract_text(const sbuf_t &sbuf);
#endif
