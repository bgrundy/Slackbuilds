(cd ..;sh bootstrap.sh)
