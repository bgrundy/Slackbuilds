- [ ] Legacy ETA display if stdout is a pipe (not a tty); switch
between the two modes.
- [ ] Python scanner.

- [ ] Generic approach for setting the carve mode for a scanner.
- [ ] Automatically set carve mode for in the main.cpp abstractly for every feature recorder based on name.
- [ ] Use leaks to check for leaks in both BE1.6 and BE2.0

# dfxml:
build environment:
- [ ] Missing CPPFLAGS, CXXFLAGS, LDFLAGS, LIBS and CFLAGS.
- [ ] Missing git commit
- [ ] sbuf_read -> debug:work_start; add t=
- [ ] sbuf_delete -> debug:work_end; add time=;
- [ ] missing <hashdigest> inside <source.>
- [ ] Does not have the time that each thread spent waiting.
- [ ] <total_bytes> is larger than it should be.
- [ ] instead of <ns>, perhaps print <seconds> ?

- [ ] scan_find.
- [ ] searches not working with regular expression to prune thme.
