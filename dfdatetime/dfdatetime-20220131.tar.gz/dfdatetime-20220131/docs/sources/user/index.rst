###############
Getting started
###############

To be able to use dfDateTime you first need to install it. There are multiple
ways to install dfDateTime, check the following instructions for more detail.

.. toctree::
   :maxdepth: 2

  Installation instructions <Installation-instructions>
